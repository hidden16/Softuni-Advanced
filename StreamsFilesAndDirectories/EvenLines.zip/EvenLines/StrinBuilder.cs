﻿namespace EvenLines
{
    internal class StrinBuilder
    {
        public StrinBuilder()
        {
        }
    }
}