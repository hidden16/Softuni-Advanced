﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasterRaces.Core.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
