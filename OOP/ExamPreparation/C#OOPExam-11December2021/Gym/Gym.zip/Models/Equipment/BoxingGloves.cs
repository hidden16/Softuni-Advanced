﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Equipment
{
    public class BoxingGloves : Equipment
    {
        public BoxingGloves() : base(227, 120m)
        {
        }
    }
}
