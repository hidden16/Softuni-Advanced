﻿namespace NavalVessels.Core.Contracts
{
    interface IEngine
    {
        void Run();
    }
}
