﻿using CommandPattern.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace CommandPattern.Core.Entities
{
    public class Engine : IEngine
    {
        private readonly ICommandInterpreter commandInterpreter;
        public Engine(ICommandInterpreter cmdInt)
        {
            commandInterpreter = cmdInt;
        }
        public void Run()
        {
            while (true)
            {
                var commands = Console.ReadLine();
                var result = commandInterpreter.Read(commands);
                Console.WriteLine(result);
            }
        }
    }
}
