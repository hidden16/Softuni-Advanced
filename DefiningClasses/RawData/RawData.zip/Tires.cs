﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData
{
    class Tires
    {
        public int TireAge { get; set; }
        public double TirePressure { get; set; }
    }
}
